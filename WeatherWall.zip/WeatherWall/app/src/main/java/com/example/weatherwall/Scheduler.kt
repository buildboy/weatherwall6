package com.example.weatherwall

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object Scheduler {
    private fun pending(ctx: Context, slot: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, slot,
            Intent(ctx, AlarmReceiver::class.java).putExtra("slot", slot),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun nextTrigger(h: Int, m: Int): Long =
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun schedule(ctx: Context, slot: Int) {
        val p = Prefs(ctx)
        if (!p.slotEnabled(slot)) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = nextTrigger(p.hour(slot), p.minute(slot))
        if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, slot))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, slot))
    }

    fun scheduleAll(ctx: Context) {
        cancelAll(ctx)
        if (Prefs(ctx).url.isNotBlank()) for (slot in 0 until Prefs.SLOTS) schedule(ctx, slot)
    }

    fun cancelAll(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (slot in 0 until Prefs.SLOTS) am.cancel(pending(ctx, slot))
    }
}
