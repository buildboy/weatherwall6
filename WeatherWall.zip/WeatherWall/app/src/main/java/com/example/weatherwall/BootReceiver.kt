package com.example.weatherwall

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a reboot or app update: restore the schedule and relaunch the display. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleAll(ctx)
        val relaunch = intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        if (relaunch && Prefs(ctx).url.isNotBlank()) {
            try {
                ctx.startActivity(
                    Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) { /* needs "display over other apps" permission */ }
        }
    }
}
